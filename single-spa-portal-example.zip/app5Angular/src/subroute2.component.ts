import {Component} from '@angular/core';

@Component({
	template: `
		<div>
			Subroute 2 is working!
		</div>
	`,
})
export class Subroute2 {
}
