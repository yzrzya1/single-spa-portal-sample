import angular from 'angular';
import '@uirouter/angularjs';

angular
    .module('app', ['ui.router']);
